param foundation object
param image string
@allowed(['api', 'worker'])
param role string
param revisionSuffix string
param authTenantId string
param authAudience string
param stableRevision string = ''
param aiMode string = 'local'
param aiEndpoint string = ''
param aiDeployment string = ''
param aiApiVersion string = ''
module app 'modules/app.bicep' = {
  name: 'app-${role}'
  params: {
    foundation: foundation
    image: image
    role: role
    revisionSuffix: revisionSuffix
    authTenantId: authTenantId
    authAudience: authAudience
    stableRevision: stableRevision
    aiMode: aiMode
    aiEndpoint: aiEndpoint
    aiDeployment: aiDeployment
    aiApiVersion: aiApiVersion
  }
}
output result object = { name: app.outputs.name, revision: app.outputs.latestRevision, fqdn: app.outputs.fqdn }
