param foundation object
param image string
@allowed(['bootstrap', 'migrate'])
param phase string = 'migrate'
module migration 'modules/migration-job.bicep' = {
  name: 'migration-job'
  params: { foundation: foundation, image: image, phase: phase }
}
output jobName string = migration.outputs.name
