param prefix string
param email string
param appInsightsId string
param workspaceId string
param location string
param budgetAmount int
param budgetStart string

resource group 'Microsoft.Insights/actionGroups@2023-01-01' = {
  name: '${prefix}-ops'
  location: 'global'
  properties: {
    groupShortName: 'aiops'
    enabled: true
    emailReceivers: [{ name: 'owner', emailAddress: email, useCommonAlertSchema: true }]
  }
}
resource failure 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: '${prefix}-failed-requests'
  location: 'global'
  properties: {
    description: 'Investigate failing API requests'
    severity: 2
    enabled: true
    scopes: [appInsightsId]
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [{
        name: 'failed'
        metricNamespace: 'microsoft.insights/components'
        metricName: 'requests/failed'
        operator: 'GreaterThan'
        threshold: 5
        timeAggregation: 'Count'
        criterionType: 'StaticThresholdCriterion'
      }]
    }
    actions: [{ actionGroupId: group.id }]
  }
}
resource budget 'Microsoft.Consumption/budgets@2023-11-01' = {
  name: '${prefix}-budget'
  properties: {
    category: 'Cost'
    amount: budgetAmount
    timeGrain: 'Monthly'
    timePeriod: { startDate: budgetStart, endDate: dateTimeAdd(budgetStart, 'P5Y') }
    notifications: {
      actual80: {
        enabled: true
        operator: 'GreaterThan'
        threshold: 80
        thresholdType: 'Actual'
        contactEmails: [email]
      }
    }
  }
}

resource stalled 'Microsoft.Insights/scheduledQueryRules@2023-12-01' = {
  name: '${prefix}-worker-stalled'
  location: location
  properties: {
    displayName: 'Worker heartbeat missing or outbox older than 120 seconds'
    severity: 2
    enabled: true
    scopes: [workspaceId]
    evaluationFrequency: 'PT5M'
    windowSize: 'PT5M'
    criteria: {
      allOf: [{
        query: '''
AppTraces
| where AppRoleName == "ai-ops-lab-worker"
| where Message startswith "worker_heartbeat"
| extend age=todouble(extract(@"oldest_seconds=([0-9.]+)",1,Message))
| summarize heartbeats=count(), oldest=max(age)
| where heartbeats == 0 or oldest > 120
'''
        timeAggregation: 'Count'
        operator: 'GreaterThan'
        threshold: 0
        failingPeriods: { numberOfEvaluationPeriods: 1, minFailingPeriodsToAlert: 1 }
      }]
    }
    actions: { actionGroups: [group.id] }
    skipQueryValidation: true
  }
}
