param accountName string
param workerPrincipalId string
resource ai 'Microsoft.CognitiveServices/accounts@2023-05-01' existing = { name: accountName }
resource access 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(ai.id, workerPrincipalId, 'openai-user')
  scope: ai
  properties: {
    principalId: workerPrincipalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '5e0bd9bd-7b93-4f28-af87-19fc36ad61bd')
  }
}
