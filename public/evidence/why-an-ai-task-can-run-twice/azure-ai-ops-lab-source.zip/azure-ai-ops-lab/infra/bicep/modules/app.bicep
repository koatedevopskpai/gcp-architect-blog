param foundation object
param image string
param role string
param revisionSuffix string
param authTenantId string
param authAudience string
param stableRevision string = ''
param aiMode string = 'local'
param aiEndpoint string = ''
param aiDeployment string = ''
param aiApiVersion string = ''

var isApi = role == 'api'
var identity = isApi ? foundation.apiIdentity : foundation.workerIdentity
var identityId = identity.id
var secrets = ['db-${role}', 'appinsights']
var secretRefs = [for name in secrets: {
  name: name
  keyVaultUrl: '${foundation.vaultUri}secrets/${name}'
  identity: identityId
}]
var commonEnv = [
  { name: 'APP_ENV', value: 'azure' }
  { name: 'AUTH_MODE', value: 'entra' }
  { name: 'AUTH_TENANT_ID', value: authTenantId }
  { name: 'AUTH_AUDIENCE', value: authAudience }
  { name: 'DATABASE_URL', secretRef: 'db-${role}' }
  { name: 'APPLICATIONINSIGHTS_CONNECTION_STRING', secretRef: 'appinsights' }
  { name: 'AZURE_CLIENT_ID', value: identity.clientId }
  { name: 'STORAGE_ACCOUNT_URL', value: foundation.storageUrl }
  { name: 'AI_MODE', value: aiMode }
  { name: 'AZURE_OPENAI_ENDPOINT', value: aiEndpoint }
  { name: 'AZURE_OPENAI_DEPLOYMENT', value: aiDeployment }
  { name: 'AZURE_OPENAI_API_VERSION', value: aiApiVersion }
]
resource app 'Microsoft.App/containerApps@2025-01-01' = {
  name: '${foundation.prefix}-${role}'
  location: foundation.location
  identity: { type: 'UserAssigned', userAssignedIdentities: { '${identityId}': {} } }
  properties: {
    managedEnvironmentId: foundation.environmentId
    workloadProfileName: 'Consumption'
    configuration: union({
      activeRevisionsMode: isApi ? 'Multiple' : 'Single'
      registries: [{ server: foundation.registry, identity: identityId }]
      secrets: secretRefs
    }, isApi ? {
      ingress: {
        external: true
        targetPort: 8000
        transport: 'http'
        allowInsecure: false
        traffic: empty(stableRevision) ? [{ latestRevision: true, weight: 100 }] : [
          { revisionName: stableRevision, weight: 100 }
          { latestRevision: true, weight: 0 }
        ]
      }
    } : {})
    template: {
      revisionSuffix: revisionSuffix
      terminationGracePeriodSeconds: 30
      containers: [union({
        name: role
        image: image
        env: commonEnv
        resources: { cpu: json('0.5'), memory: '1Gi' }
      }, isApi ? {
        probes: [
          { type: 'Startup', httpGet: { path: '/health/live', port: 8000 }, periodSeconds: 3, failureThreshold: 30 }
          { type: 'Liveness', httpGet: { path: '/health/live', port: 8000 }, periodSeconds: 10 }
          { type: 'Readiness', httpGet: { path: '/health/ready', port: 8000 }, periodSeconds: 5 }
        ]
      } : { command: ['python', '-m', 'src.worker.main'] })]
      scale: {
        minReplicas: 1
        maxReplicas: 3
        rules: isApi ? [{
          name: 'http'
          http: { metadata: { concurrentRequests: '20' } }
        }] : [{
          name: 'queue'
          custom: {
            type: 'azure-queue'
            identity: identityId
            metadata: {
              accountName: split(split(foundation.storageUrl, '//')[1], '.')[0]
              queueName: 'tasks'
              queueLength: '5'
            }
          }
        }]
      }
    }
  }
}
output name string = app.name
output latestRevision string = app.properties.latestRevisionName
output fqdn string = isApi ? app.properties.configuration.ingress.fqdn : ''
