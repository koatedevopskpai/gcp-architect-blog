param foundation object
param image string
@allowed(['bootstrap', 'migrate'])
param phase string = 'migrate'

var identityId = phase == 'bootstrap' ? foundation.bootstrapIdentity.id : foundation.migrationIdentity.id
var secretNames = phase == 'bootstrap' ? ['db-admin', 'db-api', 'db-worker', 'db-migration'] : ['db-migration']
resource job 'Microsoft.App/jobs@2024-03-01' = {
  name: '${foundation.prefix}-${phase}'
  location: foundation.location
  identity: { type: 'UserAssigned', userAssignedIdentities: { '${identityId}': {} } }
  properties: {
    environmentId: foundation.environmentId
    workloadProfileName: 'Consumption'
    configuration: {
      triggerType: 'Manual'
      replicaTimeout: 600
      replicaRetryLimit: 0
      manualTriggerConfig: { parallelism: 1, replicaCompletionCount: 1 }
      registries: [{ server: foundation.registry, identity: identityId }]
      secrets: [for name in secretNames: {
        name: name
        keyVaultUrl: '${foundation.vaultUri}secrets/${name}'
        identity: identityId
      }]
    }
    template: {
      containers: [{
        name: 'migrate'
        image: image
        command: phase == 'bootstrap' ? ['python', '-m', 'scripts.db_roles'] : ['python', '-m', 'alembic', 'upgrade', 'head']
        resources: { cpu: json('0.5'), memory: '1Gi' }
        env: concat(phase == 'bootstrap' ? [
          { name: 'ADMIN_DATABASE_URL', secretRef: 'db-admin' }
          { name: 'API_DATABASE_URL', secretRef: 'db-api' }
          { name: 'WORKER_DATABASE_URL', secretRef: 'db-worker' }
        ] : [], [
          { name: 'MIGRATION_DATABASE_URL', secretRef: 'db-migration' }
        ])
      }]
    }
  }
}
output name string = job.name
