param prefix string
param location string

resource logs 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: '${prefix}-logs'
  location: location
  properties: {
    retentionInDays: 30
    sku: { name: 'PerGB2018' }
    workspaceCapping: { dailyQuotaGb: 1 }
  }
}
resource appi 'Microsoft.Insights/components@2020-02-02' = {
  name: '${prefix}-appi'
  location: location
  kind: 'web'
  properties: { Application_Type: 'web', WorkspaceResourceId: logs.id }
}
output workspaceId string = logs.properties.customerId
output workspaceResourceId string = logs.id
@secure()
output workspaceKey string = logs.listKeys().primarySharedKey
output appInsightsId string = appi.id
output connectionString string = appi.properties.ConnectionString
