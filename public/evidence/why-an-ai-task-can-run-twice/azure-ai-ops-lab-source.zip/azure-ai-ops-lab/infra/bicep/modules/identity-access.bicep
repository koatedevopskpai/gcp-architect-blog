param prefix string
param location string
param acrName string
param vaultName string
param storageName string

var workloads = ['api', 'worker', 'migrate', 'bootstrap']
resource identities 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' = [for item in workloads: {
  name: '${prefix}-${item}'
  location: location
}]
resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' existing = { name: acrName }
resource vault 'Microsoft.KeyVault/vaults@2023-07-01' existing = { name: vaultName }
resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' existing = { name: storageName }

resource pulls 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for (item,i) in workloads: {
  name: guid(acr.id, identities[i].id, 'pull')
  scope: acr
  properties: {
    principalId: identities[i].properties.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '7f951dda-4ed3-4680-a7ca-43fe172d538d')
  }
}]
var reads = [
  { index: 0, secret: 'db-api' }
  { index: 0, secret: 'appinsights' }
  { index: 1, secret: 'db-worker' }
  { index: 1, secret: 'appinsights' }
  { index: 2, secret: 'db-migration' }
  { index: 3, secret: 'db-admin' }
  { index: 3, secret: 'db-api' }
  { index: 3, secret: 'db-worker' }
  { index: 3, secret: 'db-migration' }
]
resource namedSecrets 'Microsoft.KeyVault/vaults/secrets@2023-07-01' existing = [for item in reads: {
  parent: vault
  name: item.secret
}]
resource secrets 'Microsoft.Authorization/roleAssignments@2022-04-01' = [for (item,i) in reads: {
  name: guid(namedSecrets[i].id, identities[item.index].id, 'read')
  scope: namedSecrets[i]
  properties: {
    principalId: identities[item.index].properties.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '4633458b-17de-408a-b874-0445c86b69e6')
  }
}]
resource queue 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storage.id, identities[1].id, 'queue')
  scope: storage
  properties: {
    principalId: identities[1].properties.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '974c5e8b-45b9-4653-ba55-5f855dd0fb88')
  }
}
output api object = { id: identities[0].id, clientId: identities[0].properties.clientId }
output worker object = { id: identities[1].id, clientId: identities[1].properties.clientId }
output migrate object = { id: identities[2].id, clientId: identities[2].properties.clientId }
output bootstrap object = { id: identities[3].id, clientId: identities[3].properties.clientId }
output workerPrincipalId string = identities[1].properties.principalId
