targetScope = 'resourceGroup'
param location string = resourceGroup().location
param prefix string = 'aiops'
param ownerEmail string
param budgetAmount int = 100
param budgetStart string
@secure()
param adminPassword string
@secure()
param apiPassword string
@secure()
param workerPassword string
@secure()
param migrationPassword string
param aiAccountName string = ''
param aiResourceGroup string = resourceGroup().name

var suffix = uniqueString(subscription().id, resourceGroup().id)
var acrName = 'acr${suffix}'
var vaultName = 'kv-${suffix}'
var storageName = 'st${suffix}'

module network 'modules/network.bicep' = {
  name: 'network'
  params: { prefix: prefix, location: location }
}
module database 'modules/postgres.bicep' = {
  name: 'postgres'
  params: {
    name: 'pg-${suffix}'
    location: location
    subnetId: network.outputs.dbSubnetId
    dnsZoneId: network.outputs.dnsZoneId
    adminPassword: adminPassword
  }
}
module monitoring 'modules/monitoring.bicep' = {
  name: 'monitoring'
  params: { prefix: prefix, location: location }
}
resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' = {
  name: acrName
  location: location
  sku: { name: 'Basic' }
  properties: { adminUserEnabled: false }
}
resource storage 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageName
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    allowSharedKeyAccess: false
  }
}
resource service 'Microsoft.Storage/storageAccounts/queueServices@2023-05-01' = {
  parent: storage
  name: 'default'
}
resource queues 'Microsoft.Storage/storageAccounts/queueServices/queues@2023-05-01' = [for name in ['tasks', 'tasks-dlq']: {
  parent: service
  name: name
}]
resource vault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: vaultName
  location: location
  properties: {
    tenantId: tenant().tenantId
    sku: { family: 'A', name: 'standard' }
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 7
  }
}
var dbUsers = ['labadmin', 'api', 'worker', 'migrator']
var dbPasswords = [adminPassword, apiPassword, workerPassword, migrationPassword]
var secretNames = ['db-admin', 'db-api', 'db-worker', 'db-migration']
resource dbSecrets 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = [for (user,i) in dbUsers: {
  parent: vault
  name: secretNames[i]
  properties: {
    value: 'postgresql://${user}:${uriComponent(dbPasswords[i])}@${database.outputs.host}:5432/app?sslmode=require'
  }
}]
resource appiSecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
  parent: vault
  name: 'appinsights'
  properties: { value: monitoring.outputs.connectionString }
}
module access 'modules/identity-access.bicep' = {
  name: 'access'
  dependsOn: [dbSecrets, appiSecret]
  params: {
    prefix: prefix
    location: location
    acrName: acr.name
    vaultName: vault.name
    storageName: storage.name
  }
}
module aiAccess 'modules/openai-access.bicep' = if (!empty(aiAccountName)) {
  name: 'ai-access'
  scope: resourceGroup(aiResourceGroup)
  params: { accountName: aiAccountName, workerPrincipalId: access.outputs.workerPrincipalId }
}
resource environment 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: '${prefix}-env'
  location: location
  properties: {
    workloadProfiles: [{ name: 'Consumption', workloadProfileType: 'Consumption' }]
    vnetConfiguration: { infrastructureSubnetId: network.outputs.appsSubnetId }
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: monitoring.outputs.workspaceId
        sharedKey: monitoring.outputs.workspaceKey
      }
    }
  }
}
module alerts 'modules/alerts.bicep' = {
  name: 'alerts'
  params: {
    prefix: prefix
    email: ownerEmail
    appInsightsId: monitoring.outputs.appInsightsId
    workspaceId: monitoring.outputs.workspaceResourceId
    location: location
    budgetAmount: budgetAmount
    budgetStart: budgetStart
  }
}
output foundation object = {
  prefix: prefix
  location: location
  environmentId: environment.id
  registry: acr.properties.loginServer
  acrName: acr.name
  vaultUri: vault.properties.vaultUri
  storageUrl: 'https://${storage.name}.queue.${az.environment().suffixes.storage}'
  apiIdentity: access.outputs.api
  workerIdentity: access.outputs.worker
  migrationIdentity: access.outputs.migrate
  bootstrapIdentity: access.outputs.bootstrap
}
