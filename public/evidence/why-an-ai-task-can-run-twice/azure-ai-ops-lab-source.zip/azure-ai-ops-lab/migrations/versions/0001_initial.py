"""Durable tasks, dispatch and terminal intent schema."""

from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
        CREATE TABLE tasks (
            id uuid PRIMARY KEY,
            tenant_id text NOT NULL,
            idempotency_key text NOT NULL,
            payload_hash text NOT NULL,
            payload jsonb NOT NULL,
            trace jsonb NOT NULL DEFAULT '{}',
            status text NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','running','retry_wait',
                                  'completed','failed','timed_out','cancelled')),
            execution_attempts integer NOT NULL DEFAULT 0,
            result jsonb,
            reason text,
            claim_token uuid,
            claim_until timestamptz,
            available_at timestamptz NOT NULL DEFAULT now(),
            notified_at timestamptz NOT NULL DEFAULT now(),
            created_at timestamptz NOT NULL DEFAULT now(),
            updated_at timestamptz NOT NULL DEFAULT now(),
            UNIQUE (tenant_id,idempotency_key),
            CHECK ((claim_token IS NULL) = (claim_until IS NULL))
        );
        CREATE TABLE intents (
            id uuid PRIMARY KEY,
            task_id uuid REFERENCES tasks(id),
            tenant_id text NOT NULL,
            kind text NOT NULL CHECK (kind IN ('work','dlq','quarantine')),
            body jsonb NOT NULL DEFAULT '{}',
            trace jsonb NOT NULL DEFAULT '{}',
            owner uuid,
            lease_until timestamptz,
            publish_attempts integer NOT NULL DEFAULT 0,
            available_at timestamptz NOT NULL DEFAULT now(),
            dispatched_at timestamptz,
            created_at timestamptz NOT NULL DEFAULT now()
        );
        CREATE INDEX intent_pending ON intents(available_at)
            WHERE dispatched_at IS NULL;
        CREATE INDEX intent_task ON intents(task_id);
        CREATE INDEX task_recovery ON tasks(status,available_at,claim_until);
    """)


def downgrade():
    raise RuntimeError("destructive downgrade disabled; restore or forward-fix")
