import asyncio
import os
import signal
import subprocess
import sys
from uuid import uuid4

import pytest

from src.common.settings import Settings
from src.infra.storage_queue import StorageQueue


@pytest.fixture
async def broker():
    value = os.environ.get("AZURITE_CONNECTION_STRING")
    if not value:
        pytest.skip("AZURITE_CONNECTION_STRING not set")
    settings = Settings(
        app_env="test",
        storage_connection_string=value,
        queue_name=f"t-{uuid4().hex}",
        dlq_name=f"d-{uuid4().hex}",
        _env_file=None,
    )
    queue = StorageQueue(settings)
    await queue.main.create_queue()
    await queue.dlq.create_queue()
    yield queue
    await queue.main.delete_queue()
    await queue.dlq.delete_queue()
    await queue.close()


@pytest.mark.integration
async def test_real_visibility_receipts_and_iteration(broker):
    await broker.send('{"example":1}')
    delivery = await broker.receive()
    assert delivery.count == 1
    assert await broker.receive() is None
    old_receipt = delivery.receipt
    await broker.nack(delivery, 0)
    assert delivery.receipt != old_receipt
    delivery = await broker.receive()
    assert delivery.count == 2
    await broker.complete(delivery)
    assert await broker.receive() is None


@pytest.mark.integration
async def test_real_visibility_expiry(broker):
    broker.visibility = 1
    await broker.send('{"expiry":true}')
    first = await broker.receive()
    assert await broker.receive() is None
    await asyncio.sleep(1.2)
    second = await broker.receive()
    assert second.id == first.id and second.count == 2
    await broker.complete(second)


@pytest.mark.integration
@pytest.mark.process
@pytest.mark.skipif(
    sys.platform == "win32", reason="POSIX signal test runs in Linux CI"
)
async def test_real_sigterm_process_releases_claim(repo, broker, tmp_path):
    if sys.platform == "win32":
        pytest.skip("POSIX signal contract is verified on Linux CI")
    task = await repo.submit("tenant-a", "signal", {"text": "synthetic"}, {})
    env = dict(os.environ)
    env.update(
        {
            "APP_ENV": "test",
            "AUTH_MODE": "local",
            "DATABASE_URL": os.environ["TEST_DATABASE_URL"],
            "STORAGE_CONNECTION_STRING": os.environ["AZURITE_CONNECTION_STRING"],
            "QUEUE_NAME": broker.main.queue_name,
            "DLQ_NAME": broker.dlq.queue_name,
            "LOCAL_AI_DELAY_SECONDS": "30",
        }
    )
    with (tmp_path / "worker.log").open("w") as log:
        process = subprocess.Popen(
            [sys.executable, "-m", "src.worker.main"],
            env=env,
            stdout=log,
            stderr=log,
        )
        try:
            for _ in range(100):
                row = await repo.get("tenant-a", task["id"])
                if row["status"] == "running":
                    break
                if process.poll() is not None:
                    pytest.fail("worker exited before claim; inspect process log")
                await asyncio.sleep(0.1)
            else:
                pytest.fail("worker did not claim task")
            process.send_signal(signal.SIGTERM)
            await asyncio.to_thread(process.wait, 6)
            assert process.returncode == 0
            row = await repo.get("tenant-a", task["id"])
            assert row["status"] == "retry_wait" and row["claim_token"] is None
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
