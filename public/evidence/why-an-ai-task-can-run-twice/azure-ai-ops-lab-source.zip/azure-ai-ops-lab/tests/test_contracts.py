import asyncio
from uuid import UUID

import pytest

from src.common.models import Envelope, payload_hash
from src.common.settings import Settings


@pytest.mark.parametrize(
    "overrides",
    [
        {"queue_visibility_seconds": 60},
        {"max_execution_attempts": 0},
        {"app_env": "azure", "auth_mode": "local"},
        {"ai_mode": "azure"},
    ],
)
def test_invalid_settings_rejected(overrides):
    with pytest.raises(ValueError):
        Settings(_env_file=None, **overrides)


def test_canonical_hash():
    assert payload_hash({"a": 1, "b": 2}) == payload_hash({"b": 2, "a": 1})


async def test_authentication_required(client):
    client.headers.pop("X-Test-Tenant")
    result = await client.get("/tasks/00000000-0000-0000-0000-000000000001")
    assert result.status_code == 401


async def test_idempotency_and_payload_conflict(client, repo):
    body = {"payload": {"text": "one"}}
    headers = {"Idempotency-Key": "same"}
    first = await client.post("/tasks", json=body, headers=headers)
    second = await client.post("/tasks", json=body, headers=headers)
    conflict = await client.post(
        "/tasks", json={"payload": {"text": "two"}}, headers=headers
    )
    assert first.status_code == 202
    assert second.json()["id"] == first.json()["id"]
    assert conflict.status_code == 409
    async with repo.db.pool.acquire() as conn:
        assert await conn.fetchval("SELECT count(*) FROM intents") == 1


async def test_concurrent_duplicate_submission(repo):
    results = await asyncio.gather(
        *[repo.submit("a", "race", {"text": "x"}, {}) for _ in range(8)]
    )
    assert len({r["id"] for r in results}) == 1
    async with repo.db.pool.acquire() as conn:
        assert await conn.fetchval("SELECT count(*) FROM intents") == 1


async def test_tenant_scoping_and_session_label(client):
    body = {"payload": {"text": "one"}}
    response = await client.post("/tasks", json=body, headers={"Idempotency-Key": "k"})
    task_id = response.json()["id"]
    for method, suffix in [("GET", ""), ("GET", "/events"), ("DELETE", "")]:
        result = await client.request(
            method,
            f"/tasks/{task_id}{suffix}",
            headers={"X-Test-Tenant": "tenant-b"},
        )
        assert result.status_code == 404
    same = await client.post(
        "/tasks",
        json=body,
        headers={
            "Idempotency-Key": "k",
            "X-Session-Id": "new-label",
        },
    )
    assert same.json()["id"] == task_id


@pytest.mark.parametrize("body", [{}, [], {"payload": []}, {"payload": {"text": ""}}])
async def test_invalid_body(client, body):
    result = await client.post("/tasks", json=body, headers={"Idempotency-Key": "k"})
    assert result.status_code == 422


async def test_actual_byte_limit(client, repo):
    result = await client.post(
        "/tasks",
        json={"payload": {"text": "a" * 40000}},
        headers={"Idempotency-Key": "large"},
    )
    assert result.status_code == 413
    async with repo.db.pool.acquire() as conn:
        assert await conn.fetchval("SELECT count(*) FROM tasks") == 0


async def test_cancel_completed_returns_truth(repo, client, publisher, worker):
    from tests.conftest import submit

    task = await submit(repo, publisher)
    await worker.one()
    result = await client.delete(f"/tasks/{task['id']}")
    assert result.json()["status"] == "completed"


async def test_terminal_sse_snapshot(repo, client, publisher, worker):
    from tests.conftest import submit

    task = await submit(repo, publisher)
    await worker.one()
    result = await client.get(f"/tasks/{task['id']}/events")
    assert "event: done" in result.text
    assert '"status":"completed"' in result.text
    assert result.headers["content-type"].startswith("text/event-stream")


async def test_exclusive_claim(repo, publisher, queue):
    from tests.conftest import submit

    await submit(repo, publisher)
    env = Envelope.model_validate_json(queue.visible[0].content)
    outcomes = await asyncio.gather(repo.claim(env), repo.claim(env))
    assert sorted(mode for mode, _ in outcomes) == ["defer", "owned"]


async def test_cancel_fences_stale_completion(repo, publisher, queue):
    from tests.conftest import submit

    task = await submit(repo, publisher)
    env = Envelope.model_validate_json(queue.visible[0].content)
    _, owned = await repo.claim(env)
    await repo.cancel("tenant-a", task["id"])
    assert not await repo.finish(owned, "completed", {"summary": "stale"})
    assert (await repo.get("tenant-a", task["id"]))["status"] == "cancelled"


async def test_invalid_task_id(client):
    assert (await client.get("/tasks/not-a-uuid")).status_code == 422


async def test_missing_idempotency_key(client):
    result = await client.post("/tasks", json={"payload": {"text": "x"}})
    assert result.status_code == 422


async def test_idempotency_scoped_by_tenant(repo):
    a = await repo.submit("a", "same", {"text": "x"}, {})
    b = await repo.submit("b", "same", {"text": "x"}, {})
    assert UUID(str(a["id"])) != UUID(str(b["id"]))
