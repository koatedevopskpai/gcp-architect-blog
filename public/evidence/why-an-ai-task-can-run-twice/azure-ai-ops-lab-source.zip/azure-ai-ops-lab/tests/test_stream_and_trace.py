import asyncio
import socket

import httpx
import uvicorn
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from src.api.main import create_app
from src.common.telemetry import carrier
from tests.conftest import submit


async def test_disconnect_over_real_http_does_not_cancel(
    repo, settings, publisher, worker
):
    task = await submit(repo, publisher)
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    server = uvicorn.Server(
        uvicorn.Config(
            create_app(settings, repo),
            log_level="error",
            lifespan="off",
        )
    )
    running = asyncio.create_task(server.serve(sockets=[sock]))
    try:
        for _ in range(100):
            if server.started:
                break
            await asyncio.sleep(0.01)
        async with httpx.AsyncClient(timeout=3) as client:
            async with client.stream(
                "GET",
                f"http://127.0.0.1:{port}/tasks/{task['id']}/events",
                headers={"X-Test-Tenant": "tenant-a"},
            ) as response:
                assert response.status_code == 200
                async for line in response.aiter_lines():
                    if line.startswith("event:"):
                        break
        await worker.one()
        assert (await repo.get("tenant-a", task["id"]))["status"] == "completed"
    finally:
        server.should_exit = True
        await asyncio.wait_for(running, 4)
        sock.close()


async def test_context_propagates_through_durable_intent(repo, publisher, worker):
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    tracer = trace.get_tracer("test-api")
    with tracer.start_as_current_span("api.submit") as api_span:
        await repo.submit("tenant-a", "trace-key", {"text": "synthetic"}, carrier())
        parent = api_span.get_span_context()
    await publisher.one()
    await worker.one()
    execution = next(
        s for s in exporter.get_finished_spans() if s.name == "task.execute"
    )
    assert execution.context.trace_id == parent.trace_id
    assert execution.parent.span_id == parent.span_id
    assert execution.attributes["tenant.id"] == "tenant-a"
