import os
from urllib.parse import urlparse

import httpx
import pytest

from src.api.main import create_app
from src.common.db import Database, create_pool
from src.common.repository import Repository
from src.common.settings import Settings
from src.infra.local_ai_client import LocalAIClient
from src.worker.publisher import Publisher
from src.worker.worker import Worker
from tests.fakes import MemoryQueue


@pytest.fixture
def settings():
    return Settings(app_env="test", auth_mode="local", _env_file=None)


@pytest.fixture
async def repo(settings):
    url = os.environ.get("TEST_DATABASE_URL")
    if not url or not urlparse(url).path.endswith("_test"):
        pytest.fail("TEST_DATABASE_URL must name a disposable *_test PostgreSQL DB")
    db = Database(await create_pool(url))
    await db.ready()
    async with db.transaction() as conn:
        await conn.execute("TRUNCATE intents,tasks")
    yield Repository(db, settings)
    await db.close()


@pytest.fixture
def queue():
    return MemoryQueue()


@pytest.fixture
def ai():
    return LocalAIClient(delay=0.01)


@pytest.fixture
def worker(repo, queue, ai, settings):
    return Worker(repo, queue, ai, settings)


@pytest.fixture
def publisher(repo, queue):
    return Publisher(repo, queue)


@pytest.fixture
async def client(repo, settings):
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=create_app(settings, repo)),
        base_url="http://test",
        headers={"X-Test-Tenant": "tenant-a"},
    ) as value:
        yield value


async def submit(repo, publisher, key="key-1", tenant="tenant-a"):
    task = await repo.submit(
        tenant, key, {"operation": "summarize", "text": "synthetic"}, {}
    )
    await publisher.one()
    return task


async def make_due(repo):
    async with repo.db.transaction() as conn:
        await conn.execute("UPDATE tasks SET available_at=now()-interval '1 s'")
        await conn.execute("UPDATE intents SET available_at=now()-interval '1 s'")
