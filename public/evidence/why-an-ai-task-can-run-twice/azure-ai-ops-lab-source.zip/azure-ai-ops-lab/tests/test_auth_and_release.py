from types import SimpleNamespace

import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import HTTPException

from scripts import release
from src.common.auth import Authenticator
from src.common.settings import Settings


def test_signed_jwt_requires_role_tenant_issuer_audience_and_signature():
    import time

    settings = Settings(
        app_env="test",
        auth_mode="entra",
        auth_tenant_id="trusted-tenant",
        auth_audience="trusted-api",
        _env_file=None,
    )
    auth = Authenticator(settings)
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    auth.keys = SimpleNamespace(
        get_signing_key_from_jwt=lambda _: SimpleNamespace(key=key.public_key()),
    )
    claims = {
        "iss": auth.issuer,
        "aud": "trusted-api",
        "tid": "trusted-tenant",
        "sub": "caller",
        "iat": int(time.time()),
        "exp": int(time.time()) + 60,
        "roles": ["Lab.User"],
    }
    token = jwt.encode(claims, key, algorithm="RS256")
    assert auth.validate(token).tenant_id == "trusted-tenant"
    for field, value in [("iss", "foreign"), ("aud", "foreign"), ("tid", "foreign")]:
        with pytest.raises(jwt.PyJWTError):
            auth.validate(jwt.encode({**claims, field: value}, key, algorithm="RS256"))
    with pytest.raises(HTTPException) as error:
        auth.validate(jwt.encode({**claims, "roles": []}, key, algorithm="RS256"))
    assert error.value.status_code == 403
    other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    with pytest.raises(jwt.InvalidSignatureError):
        auth.validate(jwt.encode(claims, other, algorithm="RS256"))


def test_exact_job_execution_and_image(monkeypatch):
    calls = []

    def command(*args):
        calls.append(args)
        return {
            "properties": {
                "status": "Succeeded",
                "template": {
                    "containers": [{"image": "registry/repo@sha256:expected"}],
                },
            }
        }

    monkeypatch.setattr(release, "az", command)
    release.wait_execution("rg", "job", "exact-run", "registry/repo@sha256:expected")
    assert calls[0][-1] == "exact-run"
    with pytest.raises(RuntimeError, match="unexpected image"):
        release.wait_execution("rg", "job", "exact-run", "different-image")


def test_rollback_uses_captured_stable_revision():
    state = {
        "revision": "latest-candidate",
        "traffic": [
            {"revisionName": "known-good", "weight": 100},
            {"revisionName": "latest-candidate", "weight": 0},
        ],
    }
    assert release.stable_revision(state) == "known-good"
    assert release.stable_revision(None) == ""
