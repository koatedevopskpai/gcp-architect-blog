"""Azure AI operations lab."""
