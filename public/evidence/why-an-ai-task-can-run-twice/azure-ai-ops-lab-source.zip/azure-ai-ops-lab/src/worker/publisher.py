import asyncio
import json
import logging

from src.common.models import Envelope

log = logging.getLogger(__name__)


class Publisher:
    def __init__(self, repository, queue):
        self.repo, self.queue = repository, queue

    async def one(self):
        event = await self.repo.lease_intent()
        if not event:
            return False
        if event["kind"] == "work":
            content = Envelope(
                event_id=event["id"],
                task_id=event["task_id"],
                tenant_id=event["tenant_id"],
                trace=event["trace"],
            ).model_dump_json()
        else:
            content = json.dumps(
                {
                    "version": 1,
                    "event_id": str(event["id"]),
                    "task_id": str(event["task_id"]) if event["task_id"] else None,
                    "kind": event["kind"],
                    "details": event["body"],
                }
            )
        try:
            async with asyncio.timeout(10):
                await self.queue.send(content, dead_letter=event["kind"] != "work")
                await self.repo.published(event)
        except Exception:
            log.exception("publication failed event=%s", event["id"])
            await self.repo.publication_failed(event)
        return True

    async def run(self, stop):
        last_reconcile = 0.0
        while not stop.is_set():
            try:
                if asyncio.get_running_loop().time() - last_reconcile > 30:
                    await self.repo.reconcile()
                    metrics = await self.repo.metrics()
                    log.info(
                        "worker_heartbeat pending=%s oldest_seconds=%s",
                        metrics["pending"],
                        metrics["oldest_seconds"],
                    )
                    last_reconcile = asyncio.get_running_loop().time()
                if await self.one():
                    continue
            except Exception:
                log.exception("publisher loop failed")
            try:
                await asyncio.wait_for(stop.wait(), 0.5)
            except TimeoutError:
                pass
