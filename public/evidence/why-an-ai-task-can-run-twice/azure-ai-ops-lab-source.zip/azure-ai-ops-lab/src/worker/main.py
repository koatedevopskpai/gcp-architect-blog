import asyncio
import logging
import signal

from src.common.runtime import ai_client, queue_client, repository
from src.common.settings import Settings
from src.common.telemetry import configure
from src.worker.publisher import Publisher
from src.worker.worker import Worker


async def main():
    settings = Settings()
    configure(settings, "ai-ops-lab-worker")
    repo = await repository(settings)
    await repo.db.ready()
    queue, ai = queue_client(settings), ai_client(settings)
    await queue.ready()
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:
            signal.signal(sig, lambda *_: loop.call_soon_threadsafe(stop.set))
    loops = [asyncio.create_task(Publisher(repo, queue).run(stop))]
    loops.extend(
        asyncio.create_task(
            Worker(repo, queue, ai, settings, stop).run(),
        )
        for _ in range(settings.worker_concurrency)
    )
    failed = []

    def ended(task):
        if not stop.is_set():
            failed.append(task)
            logging.error("runtime loop exited unexpectedly; stopping process")
            stop.set()

    for task in loops:
        task.add_done_callback(ended)
    await stop.wait()
    try:
        async with asyncio.timeout(4):
            await asyncio.gather(*loops, return_exceptions=True)
    except TimeoutError:
        for task in loops:
            task.cancel()
        logging.error("shutdown deadline: process exits with durable recovery state")
    try:
        async with asyncio.timeout(1):
            await ai.close()
            await queue.close()
            await repo.db.close()
    except TimeoutError:
        logging.error("client close deadline exceeded")
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    asyncio.run(main())
