import asyncio
import json
from uuid import UUID

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import StreamingResponse
from opentelemetry import trace

from src.common.auth import Authenticator, Principal
from src.common.models import (
    MAX_REQUEST_BYTES,
    TERMINAL,
    Submission,
    task_view,
)
from src.common.repository import KeyConflict
from src.common.telemetry import carrier


class BodyLimit:
    """Bound actual bytes before FastAPI parses them; do not trust Content-Length."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] != "POST":
            return await self.app(scope, receive, send)
        body = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            body.extend(message.get("body", b""))
            if len(body) > MAX_REQUEST_BYTES:
                await send(
                    {
                        "type": "http.response.start",
                        "status": 413,
                        "headers": [(b"content-type", b"application/json")],
                    }
                )
                await send(
                    {
                        "type": "http.response.body",
                        "body": b'{"detail":"body too large"}',
                    }
                )
                return
            if not message.get("more_body"):
                break
        delivered = False

        async def replay():
            nonlocal delivered
            if delivered:
                return await receive()
            delivered = True
            return {"type": "http.request", "body": bytes(body), "more_body": False}

        await self.app(scope, replay, send)


class LimitedStream(StreamingResponse):
    def __init__(self, *args, release, **kwargs):
        super().__init__(*args, **kwargs)
        self.release = release

    async def __call__(self, scope, receive, send):
        try:
            await super().__call__(scope, receive, send)
        finally:
            self.release()


def event(name, data):
    return f"event: {name}\ndata: {json.dumps(data, separators=(',', ':'))}\n\n"


def create_app(settings, repo, lifespan=None):
    app = FastAPI(title="Azure AI Ops Lab", lifespan=lifespan)
    app.add_middleware(BodyLimit)
    auth = Authenticator(settings)
    semaphore = asyncio.Semaphore(64)
    stream_counts: dict[tuple[str, str], int] = {}

    @app.get("/health/live")
    async def live():
        return {"status": "live"}

    @app.get("/health/ready")
    async def ready():
        try:
            async with asyncio.timeout(2):
                await repo.db.ready()
        except Exception as exc:
            raise HTTPException(503, "not ready") from exc
        return {"status": "ready"}

    @app.post("/tasks", status_code=202)
    async def submit(
        body: Submission,
        request: Request,
        principal: Principal = Depends(auth),
        idempotency_key: str = Header(min_length=1, max_length=128),
    ):
        if not idempotency_key.strip():
            raise HTTPException(422, "empty idempotency key")
        try:
            context = carrier()
            label = request.headers.get("X-Session-Id", "")
            if label and len(label) <= 100:
                context["session.id"] = label
            row = await repo.submit(
                principal.tenant_id,
                idempotency_key,
                body.payload.model_dump(),
                context,
            )
        except KeyConflict as exc:
            raise HTTPException(409, "key already used for different payload") from exc
        except Exception as exc:
            raise HTTPException(503, "durable submission unavailable") from exc
        trace.get_current_span().set_attribute("task.id", str(row["id"]))
        return task_view(row)

    async def owned(principal, task_id):
        row = await repo.get(principal.tenant_id, task_id)
        if not row:
            raise HTTPException(404, "not found")
        trace.get_current_span().set_attribute("task.id", str(task_id))
        return row

    @app.get("/tasks/{task_id}")
    async def get_task(task_id: UUID, principal: Principal = Depends(auth)):
        return task_view(await owned(principal, task_id))

    @app.delete("/tasks/{task_id}")
    async def cancel(task_id: UUID, principal: Principal = Depends(auth)):
        row = await repo.cancel(principal.tenant_id, task_id)
        if not row:
            raise HTTPException(404, "not found")
        return task_view(row)

    @app.get("/tasks/{task_id}/events")
    async def events(
        task_id: UUID,
        request: Request,
        principal: Principal = Depends(auth),
    ):
        await owned(principal, task_id)
        caller = (principal.tenant_id, principal.subject)
        if semaphore.locked() or stream_counts.get(caller, 0) >= 4:
            raise HTTPException(429, "stream capacity reached")
        stream_counts[caller] = stream_counts.get(caller, 0) + 1

        def release():
            remaining = stream_counts[caller] - 1
            if remaining:
                stream_counts[caller] = remaining
            else:
                del stream_counts[caller]

        async def stream():
            async with semaphore:
                clock = asyncio.get_running_loop().time
                end, last_hb, previous = (
                    clock() + settings.sse_max_duration_seconds,
                    0.0,
                    None,
                )
                while clock() < end and not await request.is_disconnected():
                    row = await repo.get(principal.tenant_id, task_id)
                    if row is None:
                        return
                    view = task_view(row)
                    if view != previous:
                        yield event(
                            "done" if row["status"] in TERMINAL else "snapshot", view
                        )
                        previous = view
                    if row["status"] in TERMINAL:
                        return
                    if clock() - last_hb >= settings.sse_heartbeat_seconds:
                        yield ": heartbeat\n\n"
                        last_hb = clock()
                    await asyncio.sleep(0.25)
                yield event("reconnect", {"task_id": str(task_id)})

        return LimitedStream(
            stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache, no-transform",
                "X-Accel-Buffering": "no",
            },
            release=release,
        )

    return app
