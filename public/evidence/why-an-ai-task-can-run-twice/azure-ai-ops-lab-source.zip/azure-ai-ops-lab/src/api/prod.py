from contextlib import asynccontextmanager

from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

from src.api.main import create_app
from src.common.runtime import repository
from src.common.settings import Settings
from src.common.telemetry import configure

settings = Settings()


class LazyRepository:
    target = None

    def __getattr__(self, name):
        if self.target is None:
            raise RuntimeError("repository not initialized")
        return getattr(self.target, name)


proxy = LazyRepository()


@asynccontextmanager
async def lifespan(app):
    configure(settings, "ai-ops-lab-api")
    value = await repository(settings)
    proxy.target = value
    await value.db.ready()
    yield
    await value.db.close()


app = create_app(settings, proxy, lifespan)
FastAPIInstrumentor.instrument_app(app)
