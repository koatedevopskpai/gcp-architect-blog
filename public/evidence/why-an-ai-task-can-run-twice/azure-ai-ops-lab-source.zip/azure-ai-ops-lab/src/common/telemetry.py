import logging

from opentelemetry import propagate, trace
from opentelemetry.sdk.resources import Resource


def configure(settings, name):
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s %(message)s")
    for noisy in ("azure", "httpx", "httpx2"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    if settings.applicationinsights_connection_string:
        from azure.monitor.opentelemetry import configure_azure_monitor

        configure_azure_monitor(
            connection_string=settings.applicationinsights_connection_string,
            resource=Resource.create({"service.name": name}),
        )
    elif settings.app_env == "azure":
        raise ValueError("Azure telemetry connection string is required")


def carrier():
    value: dict[str, str] = {}
    propagate.inject(value)
    return value


def worker_span(envelope):
    return trace.get_tracer("ai-ops-lab.worker").start_as_current_span(
        "task.execute",
        context=propagate.extract(envelope.trace),
        attributes={
            "task.id": str(envelope.task_id),
            "tenant.id": envelope.tenant_id,
            **(
                {"session.id": envelope.trace["session.id"]}
                if "session.id" in envelope.trace
                else {}
            ),
        },
    )
