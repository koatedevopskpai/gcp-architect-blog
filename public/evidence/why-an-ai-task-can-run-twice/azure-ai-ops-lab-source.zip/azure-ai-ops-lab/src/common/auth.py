import asyncio
from dataclasses import dataclass

import jwt
from fastapi import HTTPException, Request
from opentelemetry import trace


@dataclass(frozen=True)
class Principal:
    tenant_id: str
    subject: str


class Authenticator:
    def __init__(self, settings):
        self.settings = settings
        tenant = settings.auth_tenant_id
        self.issuer = f"https://login.microsoftonline.com/{tenant}/v2.0"
        self.keys = None
        if settings.auth_mode == "entra":
            self.keys = jwt.PyJWKClient(
                f"https://login.microsoftonline.com/{tenant}/discovery/v2.0/keys",
                timeout=5,
            )

    def validate(self, token):
        assert self.keys is not None
        key = self.keys.get_signing_key_from_jwt(token).key
        claims = jwt.decode(
            token,
            key,
            algorithms=["RS256"],
            issuer=self.issuer,
            audience=self.settings.auth_audience,
            options={"require": ["exp", "iat", "iss", "aud", "tid", "sub"]},
        )
        if claims["tid"] != self.settings.auth_tenant_id:
            raise jwt.InvalidTokenError("tenant mismatch")
        if self.settings.auth_required_role not in claims.get("roles", []):
            raise HTTPException(403, "lab role required")
        return Principal(claims["tid"], claims.get("oid", claims["sub"]))

    async def __call__(self, request: Request) -> Principal:
        session = request.headers.get("X-Session-Id", "")
        if session and len(session) <= 100:
            trace.get_current_span().set_attribute("session.id", session)
        if self.settings.auth_mode == "local":
            tenant = request.headers.get("X-Test-Tenant")
            if not tenant or len(tenant) > 100:
                raise HTTPException(401, "explicit local test tenant required")
            trace.get_current_span().set_attribute("tenant.id", tenant)
            return Principal(tenant, "local-test-user")
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            raise HTTPException(401, "bearer token required")
        try:
            principal = await asyncio.to_thread(self.validate, auth[7:])
            trace.get_current_span().set_attribute("tenant.id", principal.tenant_id)
            return principal
        except jwt.PyJWTError as exc:
            raise HTTPException(401, "invalid bearer token") from exc
