from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_env: str = "local"
    auth_mode: str = "local"
    database_url: str = "postgresql://app:local-app@localhost:5432/app"
    auth_tenant_id: str = ""
    auth_audience: str = ""
    auth_required_role: str = "Lab.User"
    azure_client_id: str = ""
    ai_mode: str = "local"
    storage_connection_string: str = ""
    storage_account_url: str = ""
    queue_name: str = "tasks"
    dlq_name: str = "tasks-dlq"
    task_timeout_seconds: float = Field(default=300, gt=0)
    finalize_budget_seconds: float = Field(default=20, gt=0)
    db_claim_seconds: float = Field(default=330, gt=0)
    queue_visibility_seconds: int = Field(default=360, gt=0, le=604800)
    max_execution_attempts: int = Field(default=3, ge=1, le=10)
    worker_concurrency: int = Field(default=1, ge=1, le=16)
    sse_max_duration_seconds: float = Field(default=180, gt=0, le=180)
    sse_heartbeat_seconds: float = Field(default=15, gt=0)
    local_ai_delay_seconds: float = Field(default=0.1, ge=0)
    local_ai_fail_first_n: int = Field(default=0, ge=0)
    azure_openai_endpoint: str = ""
    azure_openai_deployment: str = ""
    azure_openai_api_version: str = ""
    applicationinsights_connection_string: str = ""

    @model_validator(mode="after")
    def validate_profile(self):
        if self.app_env not in {"local", "azure", "test"}:
            raise ValueError("unsupported APP_ENV")
        if self.auth_mode not in {"local", "entra"}:
            raise ValueError("unsupported AUTH_MODE")
        if self.ai_mode not in {"local", "azure"}:
            raise ValueError("unsupported AI_MODE")
        if self.db_claim_seconds <= (
            self.task_timeout_seconds + self.finalize_budget_seconds
        ):
            raise ValueError("claim must exceed task plus finalization budget")
        if self.queue_visibility_seconds <= self.db_claim_seconds:
            raise ValueError("queue visibility must exceed claim duration")
        if self.auth_mode == "entra" and not (
            self.auth_tenant_id and self.auth_audience
        ):
            raise ValueError("Entra tenant and audience are required")
        if self.app_env == "azure":
            if self.auth_mode != "entra" or not self.azure_client_id:
                raise ValueError("Azure requires Entra auth and a UAMI client ID")
            if self.storage_connection_string:
                raise ValueError("Azure profile forbids storage account keys")
            if not self.storage_account_url.startswith("https://"):
                raise ValueError("Azure requires HTTPS storage URL")
        if self.ai_mode == "azure" and not all(
            [
                self.azure_openai_endpoint,
                self.azure_openai_deployment,
                self.azure_openai_api_version,
            ]
        ):
            raise ValueError("explicit Azure OpenAI configuration required")
        return self
