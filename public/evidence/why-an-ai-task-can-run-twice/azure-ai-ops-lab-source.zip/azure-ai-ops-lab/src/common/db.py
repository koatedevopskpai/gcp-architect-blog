import json
from contextlib import asynccontextmanager

import asyncpg


async def configure_connection(conn):
    for name in ("json", "jsonb"):
        await conn.set_type_codec(
            name,
            schema="pg_catalog",
            encoder=json.dumps,
            decoder=json.loads,
            format="text",
        )


async def create_pool(url: str):
    return await asyncpg.create_pool(
        url,
        min_size=2,
        max_size=16,
        command_timeout=5,
        init=configure_connection,
        server_settings={"application_name": "ai-ops-lab"},
    )


class Database:
    def __init__(self, pool):
        self.pool = pool

    @asynccontextmanager
    async def transaction(self):
        async with self.pool.acquire() as conn, conn.transaction():
            yield conn

    async def ready(self):
        async with self.pool.acquire() as conn:
            version = await conn.fetchval("SELECT version_num FROM alembic_version")
            if version != "0001":
                raise RuntimeError("schema mismatch")
            await conn.fetchval("SELECT 1 FROM tasks LIMIT 1")

    async def close(self):
        await self.pool.close()
