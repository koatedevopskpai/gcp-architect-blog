from dataclasses import dataclass


@dataclass
class Delivery:
    id: str
    receipt: str
    content: str
    count: int
