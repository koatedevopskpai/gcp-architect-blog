"""Shared contracts and database operations."""
