from src.common.db import Database, create_pool
from src.common.repository import Repository
from src.infra.local_ai_client import LocalAIClient
from src.infra.storage_queue import StorageQueue


async def repository(settings):
    db = Database(await create_pool(settings.database_url))
    return Repository(db, settings)


def ai_client(settings):
    if settings.ai_mode == "azure":
        from src.infra.azure_ai_client import AzureAIClient

        return AzureAIClient(settings)
    return LocalAIClient(
        settings.local_ai_delay_seconds, settings.local_ai_fail_first_n
    )


def queue_client(settings):
    return StorageQueue(settings)
