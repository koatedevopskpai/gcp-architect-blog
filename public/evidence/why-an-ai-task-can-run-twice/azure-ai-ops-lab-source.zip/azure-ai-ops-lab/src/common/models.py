import hashlib
import json
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

TERMINAL = {"completed", "failed", "timed_out", "cancelled"}
MAX_REQUEST_BYTES = 32768
MAX_RESULT_BYTES = 16384


class Payload(BaseModel):
    model_config = ConfigDict(extra="forbid")
    operation: Literal["summarize"] = "summarize"
    text: str = Field(min_length=1, max_length=24000)


class Submission(BaseModel):
    model_config = ConfigDict(extra="forbid")
    payload: Payload


class Result(BaseModel):
    model_config = ConfigDict(extra="forbid")
    summary: str = Field(min_length=1, max_length=8000)


class Envelope(BaseModel):
    model_config = ConfigDict(extra="forbid")
    version: Literal[1] = 1
    event_id: UUID
    task_id: UUID
    tenant_id: str = Field(min_length=1, max_length=100)
    trace: dict[str, str] = Field(default_factory=dict)


def payload_hash(payload: dict) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()


def validate_result(value: object) -> dict:
    result = Result.model_validate(value).model_dump()
    if len(json.dumps(result).encode()) > MAX_RESULT_BYTES:
        raise ValueError("result exceeds byte limit")
    return result


def task_view(row: dict) -> dict:
    return {
        "id": str(row["id"]),
        "status": row["status"],
        "attempts": row["execution_attempts"],
        "result": row["result"],
        "reason": row["reason"],
    }
