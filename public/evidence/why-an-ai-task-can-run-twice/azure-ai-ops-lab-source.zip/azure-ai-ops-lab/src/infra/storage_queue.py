from typing import Any

from azure.identity.aio import DefaultAzureCredential
from azure.storage.queue.aio import QueueClient

from src.common.messages import Delivery


class StorageQueue:
    def __init__(self, settings):
        self.credential = None
        self.visibility = settings.queue_visibility_seconds
        opts: dict[str, Any] = {
            "retry_total": 0,
            "connection_timeout": 3,
            "read_timeout": 5,
        }
        if settings.storage_connection_string:
            self.main = QueueClient.from_connection_string(
                settings.storage_connection_string,
                queue_name=settings.queue_name,
                **opts,
            )
            self.dlq = QueueClient.from_connection_string(
                settings.storage_connection_string,
                queue_name=settings.dlq_name,
                **opts,
            )
        else:
            self.credential = DefaultAzureCredential(
                managed_identity_client_id=settings.azure_client_id,
            )
            self.main = QueueClient(
                settings.storage_account_url,
                settings.queue_name,
                credential=self.credential,
                **opts,
            )
            self.dlq = QueueClient(
                settings.storage_account_url,
                settings.dlq_name,
                credential=self.credential,
                **opts,
            )

    async def send(self, content, *, dead_letter=False):
        client = self.dlq if dead_letter else self.main
        if len(content.encode()) > 48000:
            raise ValueError("broker envelope too large")
        await client.send_message(content, time_to_live=604800)

    async def receive(self):
        messages = self.main.receive_messages(
            messages_per_page=1,
            visibility_timeout=self.visibility,
        )
        async for raw in messages:
            if not raw.id or not raw.pop_receipt:
                raise ValueError("received message lacks broker receipt")
            return Delivery(
                raw.id, raw.pop_receipt, raw.content, int(raw.dequeue_count or 1)
            )
        return None

    async def complete(self, delivery):
        await self.main.delete_message(delivery.id, delivery.receipt)

    async def nack(self, delivery, delay=0):
        result = await self.main.update_message(
            delivery.id,
            pop_receipt=delivery.receipt,
            visibility_timeout=max(0, min(604800, int(delay))),
        )
        if not result.pop_receipt:
            raise ValueError("updated message lacks broker receipt")
        delivery.receipt = result.pop_receipt

    async def ready(self):
        await self.main.get_queue_properties()

    async def close(self):
        await self.main.close()
        await self.dlq.close()
        if self.credential:
            await self.credential.close()
