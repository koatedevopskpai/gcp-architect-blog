import asyncio


class TransientAIError(Exception):
    pass


class LocalAIClient:
    def __init__(self, delay=0.1, fail_first=0):
        self.delay, self.fail_first, self.calls = delay, fail_first, 0
        self.started = asyncio.Event()

    async def process(self, payload):
        self.calls += 1
        self.started.set()
        await asyncio.sleep(self.delay)
        if self.calls <= self.fail_first:
            raise TransientAIError("deterministic transient failure")
        return {"summary": payload["text"][:200]}

    async def close(self):
        pass
