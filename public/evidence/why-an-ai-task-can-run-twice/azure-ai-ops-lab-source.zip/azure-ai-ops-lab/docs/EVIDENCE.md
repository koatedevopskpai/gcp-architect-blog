# Evidence register

All live Azure entries start pending. A checklist is not proof of completion.

| ID | Scenario | Required record | State |
|---|---|---|---|
| E01 | Local task and duplicate submission | Smoke output and commit | Pending operator run |
| E02 | Completed result then lost ack | Test report, one AI call, two deliveries | See VALIDATION |
| E03 | Provider response before commit | Repeated AI call limitation | See VALIDATION |
| E04 | Queue outage | Durable task and later dispatch | See VALIDATION |
| E05 | Claims/cancellation/expired owner | PostgreSQL race tests | See VALIDATION |
| E06 | Real Linux SIGTERM | Process test plus elapsed time | Pending Linux CI |
| E07 | Private PostgreSQL and migration | Job ID, image digest, connectivity | Pending Azure |
| E08 | CI blocks merge | Failed PR and branch protection | Pending GitHub |
| E09 | Candidate failure and rollback | Captured stable API/worker state | Pending Azure |
| E10 | Trace topology and attributes | Exported span relationship | See VALIDATION |
| E11 | Versionless secret rotation | Redacted config and pickup time | Pending Azure |
| E12 | p95/recovery and scaling | Query, counts, load profile and duration | Pending Azure |
| E13 | Cost and teardown | Dated worksheet, deletion inventory | Pending Azure |

For each completed entry record UTC start/end, commit, image digest, environment,
model/local mode, input load, actual result, linked artifact and remaining limits.
Keep career rates, personal negotiation thresholds and private recruiter context
outside the shareable technical repository.
