# Official technical references

Checked 23 October 2026. The source code still needs live tenant acceptance.

- Managed identity selection: https://learn.microsoft.com/azure/container-apps/managed-identity
- Secrets and rotation: https://learn.microsoft.com/azure/container-apps/manage-secrets
- Revisions: https://learn.microsoft.com/azure/container-apps/revisions
- Candidate label URLs: https://learn.microsoft.com/azure/container-apps/blue-green-deployment
- Jobs and exact execution: https://learn.microsoft.com/cli/azure/containerapp/job/execution
- Scaling identities: https://learn.microsoft.com/azure/container-apps/scale-app
- Container Apps 2025-01-01 schema: https://learn.microsoft.com/azure/templates/microsoft.app/2025-01-01/containerapps
- Python queue API: https://learn.microsoft.com/python/api/azure-storage-queue/azure.storage.queue.queueclient
- PostgreSQL private networking: https://learn.microsoft.com/azure/postgresql/network/concepts-networking-private
- OpenTelemetry propagation: https://opentelemetry.io/docs/languages/python/propagation/
