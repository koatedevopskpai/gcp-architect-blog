# Full-scope cost worksheet

No fixed monthly total is asserted. Fill this before leaving Azure resources up.

| Input | Selected value |
|---|---|
| Pricing date / currency / region | Pending |
| Calculator link and subscription offer | Pending |
| Continuous-month duration | Pending |
| Short evidence-capture duration | Pending |
| Expected requests and model tokens | Pending |
| Applicable allowances, taxes and shared services | Pending |

| Resource | Quantities to price |
|---|---|
| API | 0.5 vCPU / 1 GiB; minimum one replica; active/idle/request hours |
| Worker/publisher | 0.5 vCPU / 1 GiB; minimum one; scaled replicas and duration |
| Bootstrap/migration Jobs | Executions, duration and resources |
| PostgreSQL | B1ms, 32 GiB, backup retention/overage, running hours |
| ACR | Basic registry, image storage and remote builds |
| Storage Queue | Operations, message storage and retries |
| Key Vault | Operations, secret versions and retention |
| Log Analytics/App Insights | Ingestion, retention, queries/exports and sampling |
| Network | Private DNS, egress and any added NAT/firewall/endpoints |
| Azure OpenAI | Chosen model and all actual calls, including retries |
| CI and evidence storage | Build minutes, reports and retained artifacts |

Estimate both continuous operation and a short run. The budgetAmount is in billing
currency and is a notification threshold, not a hard cap. Capture billing after a
short run when delayed usage arrives. Deleting only API/worker/ACR leaves other
charges. Export evidence, use the tagged-group teardown, wait for deletion and
inspect separately scoped identities, permissions, retained vaults and storage.
