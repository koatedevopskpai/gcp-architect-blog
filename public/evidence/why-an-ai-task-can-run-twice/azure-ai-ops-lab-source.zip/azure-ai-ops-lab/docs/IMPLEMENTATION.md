# Implementation sequence and gates

This file is the ordered build guide. Full listings appear in the companion PDF;
all files also exist in the ZIP. Edit and run the repository files, not PDF text
with display line numbers or wrapped lines.

## Phase 1 - foundation contracts

Create pyproject.toml, .gitignore, .dockerignore, .env.example and both requirement
locks. Then create src package markers and common/settings.py, models.py,
messages.py and telemetry.py. Install requirements-dev.txt in Python 3.14.

Gate: invalid environment/timing settings fail, payload hashing is canonical,
and the request/result byte limits are explicit. Settings require queue visibility
to exceed the claim, which exceeds the task and finalization budget.

## Phase 2 - persistence and permissions

Create alembic.ini, migrations/env.py and versions/0001_initial.py. Implement
common/db.py, repository.py and scripts/local_roles.sql and db_roles.py. The SQL
repository replaces the earlier partial ORM sketch: it exposes the complete
ownership transitions directly and uses PostgreSQL row locks.

Gate: alembic upgrade head creates the schema. Race duplicate submissions and
claims against PostgreSQL; test rollback between task insert and intent insert.
The API/worker can read/write application tables but cannot create schema objects.
Only migrator owns schema changes. Role bootstrap is an elevated separate action.

## Phase 3 - external adapters

Implement infra/local_ai_client.py, azure_ai_client.py and storage_queue.py.
Runtime wiring in common/runtime.py connects those adapters to one repository.
Azure uses an explicitly selected UAMI; local mode uses emulator credentials.
The production adapter never creates queues. Local scripts/init_queue.py does.

Gate: real Azurite send, paged receive, visibility expiry, fresh pop receipts,
deletion and empty receive all work. The local AI stub fails deterministically.
An Azure provider call remains pending until a real model deployment is tested.

## Phase 4 - publisher and consumer

Implement worker/publisher.py, worker/worker.py and worker/main.py. Publication
leases are database rows; a send/mark crash can duplicate a notification. Claims
and fenced completion prevent a stale worker from committing over a newer owner.
Retry, timeout and DLQ intents commit before original-message acknowledgement.

Gate: test completed-result ack loss, provider-response/pre-commit failure,
transient retry, terminal attempt cap, poison-message quarantine, cancelled work,
expired claims and shutdown. Count actual model calls separately from deliveries.
Keep minimum one worker replica because that app also hosts the publisher.

## Phase 5 - API and identity

Implement common/auth.py, api/main.py and api/prod.py. Azure validates a signed
v2 Entra access token, tenant, audience and Lab.User role. Local mode requires an
explicit X-Test-Tenant header. API submission commits task and outbox together;
readiness checks the database contract and schema, while worker alerts monitor
queue/outbox progress. Add scripts/smoke.py.

Gate: missing authentication is rejected; another tenant cannot read, stream or
cancel a task. Same key/different payload returns 409. Completion/cancellation
races have one winner. Real HTTP disconnect leaves work independent of the stream.

## Phase 6 - automated checks and local run

Create every file under tests/, Dockerfile and docker-compose.yml. Run Compose,
then scripts.smoke. Run the PostgreSQL suite with TEST_DATABASE_URL pointing to a
disposable *_test database, and Azurite integration with its explicit connection
string. Linux CI runs the real worker entrypoint and sends SIGTERM.

Gate: formatter, lint, mypy, all applicable tests and container build pass. Record
the local check results and skipped checks accurately in docs/VALIDATION.md.

## Phase 7 - Azure foundation

Create infra/config.example.json; modules/network, postgres, monitoring,
identity-access, openai-access and alerts; then bootstrap.bicep. Compile all
entrypoints. Run scripts/setup_identity explicitly and configure GitHub `lab`.
Populate non-secret infra/config.json and four stable environment passwords.

Gate: first foundation deployment creates registry without referencing an
unpublished image. The database is private, the app environment is VNet-integrated,
and identity permissions are assigned at their intended resource/secret scopes.
Confirm all DNS, quota and provider-registration prerequisites in the target tenant.

## Phase 8 - migrations and applications

Create modules/migration-job.bicep, migration.bicep, modules/app.bicep and
workload.bicep. The Job module supports separate bootstrap and migrate phases.
Bootstrap uses the dedicated elevated identity; ordinary migrations use the
restricted migration identity and only db-migration.

Gate: build/push the image first; deploy the chosen Job from its digest; start and
poll the exact execution returned by that call, checking its image. A failed
migration cannot promote new API traffic. This gate must be proven live in Azure.

## Phase 9 - release and GitHub protection

Create scripts/release.py, .github/workflows/ci.yml and deploy.yml. The release
captures the prior stable API revision and worker image, deploys a candidate with
zero traffic on subsequent releases, rolls the worker, smokes a task through the
candidate, then shifts API traffic. A worker rollback restores its image; an API
traffic shift alone does not roll a worker back.

Gate: require CI/quality, CI/tests and CI/container in branch protection after the
first check run. Verify the exact check names GitHub displays. Restrict environment
deployments to main. Demonstrate a failed required check and a failed candidate.
The first API deployment has no old revision: its authenticated endpoint becomes
available during bootstrap and is accepted only after smoke succeeds.

## Phase 10 - evidence, costs and cleanup

Fill docs/EVIDENCE.md and COST.md. Use docs/queries.kql for measurements and alert
investigation. Run recovery drills in RUNBOOK.md. Export evidence before running
scripts/teardown.sh with the exact subscription/group. Verify deletion completion.

Gate: evidence states the commit/image, scenario, timestamps, sample size and
limitations. Include database/network costs and minimum-one worker hours. Optional
Elixir or managed-sandbox extensions come after these core gates, not inside them.
