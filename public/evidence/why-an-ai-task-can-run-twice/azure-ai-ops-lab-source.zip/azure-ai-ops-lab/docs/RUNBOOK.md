# Operations runbook

## Failed release

Inspect the uploaded release manifest: it identifies the image and exact Job
execution. Use `az containerapp job execution show` with that execution name.
Generic release errors intentionally avoid printing deployment arguments containing
secrets; inspect Azure deployment operations privately for the detailed cause.
Do not paste secret values, access tokens or complete database URLs into evidence.

For identity failures, verify the attached UAMI, client ID, named-secret scope,
ACR permission, model role and propagation. A rerun is not guaranteed to repair a
wrong scope or missing secret. Region/SKU and budget API support are tenant-specific.

## Bootstrap versus migration

The first release runs a separate db_roles Job with a bootstrap identity. That
identity can retrieve setup credentials; the ordinary migration identity cannot.
Run `scripts.release --configure-db-roles` explicitly after deliberate database
credential rotation. Coordinate active connections, old credentials and new Key
Vault versions; changing environment passwords is not an ordinary image release.

The workflow does not perform destructive schema rollback. Forward migrations must
support the old and new application while traffic/worker transitions occur. Restore
or forward-fix a failed incompatible migration through a reviewed recovery plan.

## API and worker rollback

Restore the captured stable API traffic revision, not the second-newest revision.
For a worker failure restore the captured worker image and verify task completion.
The release script attempts both; a failed rollback remains an error in the run.
Check readiness plus a real authenticated task. On the first deployment there is
no earlier image or API revision to restore; retain diagnostics and fix bootstrap.

## Queue/outbox outage

Durable submission can return 202 while the broker is down: the outbox keeps the
intent. Monitor worker_heartbeat, oldest_seconds and intent backlog. The publisher
retries with backoff and reuses event IDs. An expired publication lease can cause
duplicate sends. A pending task without a surviving notification is reconciled
after the documented 420-second stale threshold.

## Worker stop and abrupt kill

SIGTERM stops new receives. The worker cancels its local AI task, releases its
database claim and only then nacks the notification if release succeeded. Cleanup
is bounded; non-cooperative transport/remote work can outlive Python cancellation.
The platform grace setting is 30 seconds; local code targets a five-second exit.
Use Linux CI/Azure to measure real SIGTERM, rather than assuming Windows termination
has POSIX semantics. Abrupt crash recovery includes remaining 360-second visibility.

Every acquired claim consumes one execution attempt, including shutdown-interrupted
claims. Three interrupted starts can therefore reach the attempt cap. This explicit
lab policy prevents infinite restart loops; change it only with matching tests and
separate provider-call/claim accounting.

## Terminal failures and quarantine

The task state and its DLQ intent commit together. The publisher separately delivers
that intent, including when the original task notification takes a terminal fast
path. Poison bodies retain only message ID and SHA-256 in quarantine, not raw
payload. Quarantine identity is stable across redelivery. Alert on backlog, inspect
reason/event ID, fix the cause, and create a new linked task for a manual re-drive.
Do not edit a terminal row back to pending or claim exactly-once external effects.

## Secret rotation

Versionless references can refresh and restart active revisions. Measure the actual
pickup and connection-pool behaviour. Do not assume a new image revision is the only
refresh event. Coordinate database credential changes with role bootstrap, runtime
references and any retention window for the old credential.

## Monitoring

Bicep creates API-failure and stalled-worker/outbox log alerts plus a budget alert.
The log alert skips creation-time query validation because the workspace is new;
verify its AppTraces table/role-name schema and trigger it deliberately after logs
arrive. A budget sends notifications; it does not stop compute or cap spending.
