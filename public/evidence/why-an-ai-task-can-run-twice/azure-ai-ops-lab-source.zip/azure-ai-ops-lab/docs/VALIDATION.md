# Observed validation - 23 October 2026

## Checks run on this source bundle

| Check | Observed result |
|---|---|
| Automated suite | 49 passed, 1 skipped; final run 10.52 seconds |
| PostgreSQL engine | Native PostgreSQL 18.4, disposable local test database |
| Python / OS | Python 3.14.5 on Windows |
| Queue integration | Real Azurite 3.35.0; receive, visibility expiry, receipt update, delete |
| HTTP stream | Real HTTP disconnect test, terminal snapshot and reconnect tests |
| Auth | Signed RSA JWT tests: signature, issuer, audience, tenant and required role |
| Trace propagation | In-memory exporter observes API parent -> task.execute |
| Formatting / lint | Ruff format check and Ruff check passed |
| Type checking | Mypy passed for 29 runtime/operations source files |
| Infrastructure compilation | bootstrap, migration and workload entrypoints compiled with Bicep 0.48.1; no diagnostics |
| Compose structure | docker compose config --quiet passed |
| Native end-to-end smoke | API + publisher/worker + PostgreSQL roles + Azurite completed a synthetic task; duplicate key returned same ID |
| Database privilege probe | API role could read tasks; CREATE TABLE was rejected |
| Stream quota probe | Four real HTTP streams accepted, fifth rejected with 429; disconnect released quota |

The source uses direct PostgreSQL transactions/row locks, rather than silently
running concurrency tests on SQLite. The suite includes outbox rollback, competing
claims, stale-owner fencing, cancellation race, ack loss, deliberate repeated AI
invocation after pre-commit crash, durable DLQ/quarantine recovery and dispatcher
reconciliation. The local model is a deterministic stub; no real inference charge
or live Azure operation was made during authoring.

## Checks not run here

- The skipped test is the real POSIX SIGTERM process test. Windows termination is
  not treated as equivalent; Linux CI contains that test.
- Linux CI and its PostgreSQL 16 container have not run in GitHub yet.
- Docker image build and Compose service startup have not run: the Docker daemon
  was unavailable. Native services were used for the end-to-end check.
- Azure deployment/what-if, subscription permissions, regional SKU quota, Entra
  registration, real OIDC, private database networking, Key Vault rotation, KEDA,
  candidate promotion, rollback and deployed alerts remain pending.
- Azure OpenAI inference, SDK-to-provider compatibility for the chosen deployment,
  provider-side cancellation, real costs and cloud performance remain pending.
- Teardown of a live Azure resource group has not been performed.

## Reproduce

Use the commands in README and docs/IMPLEMENTATION. Supply your own disposable
*_test database and Azurite connection string, then migrate before pytest. The
observed counts above describe this bundle; update them when tests or platforms
change. CI failures are required evidence to investigate, not permission to replace
PostgreSQL tests with fakes or mark an unrun cloud check as passed.

The codebook is a reference implementation and implementation guide. It does not
assert that this repository is already deployed, production-hardened or approved
for processing real customer data. Optional Elixir and untrusted-code sandbox
implementations are intentionally outside the distributed core.
