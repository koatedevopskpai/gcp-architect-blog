# Azure AI Ops Lab

Complete reference source for the revised implementation plan, dated 23 October 2026.
Use synthetic finance notes to demonstrate controlled Azure releases, durable
submission, queue recovery, fenced task ownership, SSE snapshots and telemetry.

## What is included

FastAPI, PostgreSQL migrations, transactional outbox, publisher and consumers,
local/Azure AI adapters, authentication, failure tests, Docker Compose, Bicep,
GitHub Actions, identity bootstrap, release orchestration and operations docs.
The companion code PDF prints every distributed text file; the ZIP is the
authoritative copy/paste source. No GitHub repository is created by this bundle.

Use Python 3.14. Dependencies are resolved and pinned; regenerate them deliberately
with scripts/lock_dependencies.py. CI targets Linux and PostgreSQL 16. Local
authoring checks used Windows/Python 3.14 and PostgreSQL 18; see docs/VALIDATION.md
for the exact observed results and checks that remain pending.

## Local start

```bash
docker compose up --build
python -m venv .venv
# Activate .venv using your shell, then:
pip install -r requirements-dev.txt
python -m scripts.smoke
```

The local API listens only on localhost:8000. Its explicit X-Test-Tenant header is
a test fixture, not authentication. Azure startup rejects this auth mode.
Compose creates development database users and queues; existing database volumes
do not re-run initialization SQL. Export results before resetting a volume.

## Run the tests

Create a separate disposable PostgreSQL database whose name ends with `_test`.
Do not point the test environment at the local `app` database or an Azure database.
For a fresh local Compose installation, create its test role/database once:

```bash
docker compose exec postgres psql -U postgres -d postgres -c "CREATE ROLE lab LOGIN PASSWORD 'test-password'"
docker compose exec postgres psql -U postgres -d postgres -c "CREATE DATABASE aiops_test OWNER lab"
```

If they already exist, keep them rather than recreating them. The CI PostgreSQL
service creates its own lab role and aiops_test database automatically.

```bash
export TEST_DATABASE_URL='postgresql://lab:test-password@localhost:5432/aiops_test'
export MIGRATION_DATABASE_URL="$TEST_DATABASE_URL"
export AZURITE_CONNECTION_STRING='UseDevelopmentStorage=true'
alembic upgrade head
pytest -q
ruff format --check .
ruff check .
mypy
```

In PowerShell use `$env:NAME='value'` instead of `export NAME=value`.
Multiline examples use Bash syntax; run them on one line in PowerShell.
Tests require PostgreSQL; the suite fails rather than quietly substituting SQLite.
Azurite checks skip explicitly if AZURITE_CONNECTION_STRING is absent. The real
POSIX SIGTERM test runs on Linux and skips on Windows.

## Implementation order

1. Repository settings, dependency locks and typed models.
2. Schema, database roles, connection pool and transactional repository.
3. Local/Azure queue and AI adapters.
4. Publisher, consumer claims, retry/DLQ intents and shutdown.
5. Authentication, HTTP API, cancellation and SSE.
6. PostgreSQL, Azurite, real HTTP and process tests.
7. Compose and local smoke.
8. Azure foundation, identities and database/network connectivity.
9. Restricted migration Job, candidate application revisions and release script.
10. CI protection, OIDC environment, recovery evidence, cost and teardown.

See docs/IMPLEMENTATION.md for file-by-file gates and commands.

## Azure setup

An operator with Graph application-management rights and resource-group role
assignment rights runs the following once. It creates external identities and
assignments, so review the target tenant/subscription before running it.

```bash
az login
az account set --subscription YOUR_SUBSCRIPTION_ID
python -m scripts.setup_identity --repository OWNER/REPO \
  --resource-group rg-ai-ops-lab --location uksouth
```

Copy infra/config.example.json to infra/config.json and fill in its values from
the script output. Config contains identifiers, not passwords, and can be tracked
in a private repo. The API app uses v2 Entra tokens and the Lab.User application
role; assign human testers in the enterprise application. The deployment principal
receives the application role for candidate smoke tests.
Choose budgetStart as the first day of the initial budget month and retain that
value for ordinary later releases; the Monthly time grain handles its resets.

Create GitHub environment `lab`, restrict it to main and add required reviewers.
Set environment variables AZURE_CLIENT_ID, AZURE_TENANT_ID and
AZURE_SUBSCRIPTION_ID. Set four distinct long random environment secrets:
DB_ADMIN_PASSWORD, API_DB_PASSWORD, WORKER_DB_PASSWORD, MIGRATION_DB_PASSWORD.
Keep these values stable across ordinary redeployments. The defaults use the local
AI stub; using Azure OpenAI requires an existing model resource/deployment and
explicit API version. Cross-resource-group model access also requires assignment
permission at that resource group; it is not granted by the bootstrap script.

Register the Microsoft.App, Microsoft.OperationalInsights, Microsoft.Insights,
Microsoft.DBforPostgreSQL, Microsoft.KeyVault, Microsoft.Storage,
Microsoft.ContainerRegistry and Microsoft.ManagedIdentity providers as needed.
Confirm region/SKU quota, budget API support for the subscription offer, and the
private PostgreSQL network/DNS deployment before treating Azure acceptance as done.

Run Deploy manually from main. It first runs reusable CI. The release pushes one
image and references its digest, runs an elevated database-role setup Job only on
first deploy or explicit rotation, runs a restricted migration Job, tests the
candidate API with the worker, then promotes traffic. A failed first bootstrap has
no previous release to restore. Schema changes must remain backward compatible.

## Security and reliability boundaries

- Azure identity derives tenancy from validated tokens. A session label changes no
  authorization or idempotency scope. Tenant isolation is enforced by the API and
  repository queries, not PostgreSQL RLS.
- Runtime identities read only named secrets. The role-bootstrap Job intentionally
  has wider database setup access; the migration Job reads only its migration URL.
- A task claim counts as an execution attempt, including one interrupted by scale-in.
  Duplicate notifications and outbox publication retries do not increment it.
- A completed task's lost acknowledgement cannot cause another model call. A crash
  after provider response but before commit can repeat the model call.
- Worker minReplicas=1 keeps the co-located outbox publisher alive. Scale-to-zero is
  not enabled by this reference architecture.
- Dead-letter/quarantine entries can be published twice after acknowledgement loss;
  their event_id remains stable for deduplication.
- A Python cancellation request does not prove that a remote provider stopped
  computation or billing. POSIX process behaviour needs the Linux test.
- SSE is snapshot reconnection with a 180-second cap, not a durable replay log.
  Limits are four streams per principal and 64 total per API process, rather than
  a distributed tenant-wide rate limit. Idempotency keys persist until task cleanup
  or teardown; this lab does not silently expire them.
- The environment includes VNet/private PostgreSQL. Private endpoints for every
  downstream service, egress inspection and untrusted-code sandboxes are extensions.

See docs/RUNBOOK.md, docs/COST.md and docs/EVIDENCE.md for operations and handover.
