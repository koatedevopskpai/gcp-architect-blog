import asyncio
import os

from azure.core.exceptions import ResourceExistsError
from azure.storage.queue.aio import QueueClient


async def main():
    # Local setup service only; Azure queues are created by Bicep.
    for name in ("tasks", "tasks-dlq"):
        async with QueueClient.from_connection_string(
            os.environ["STORAGE_CONNECTION_STRING"],
            name,
        ) as queue:
            for attempt in range(30):
                try:
                    await queue.create_queue()
                    break
                except ResourceExistsError:
                    break
                except Exception:
                    if attempt == 29:
                        raise
                    await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(main())
