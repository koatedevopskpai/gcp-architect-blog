"""Verify that the extracted source matches the codebook's bundle snapshot."""

import hashlib
from pathlib import Path


def main():
    root = Path(__file__).resolve().parents[1]
    count = 0
    for line in (root / "MANIFEST.sha256").read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        digest, name = line.split("  ", 1)
        path = (root / name).resolve()
        if not path.is_relative_to(root):
            raise ValueError("manifest path escapes repository")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != digest:
            raise ValueError("content mismatch: " + name)
        count += 1
    print(f"Verified {count} source files. Manifest excludes itself.")


if __name__ == "__main__":
    main()
