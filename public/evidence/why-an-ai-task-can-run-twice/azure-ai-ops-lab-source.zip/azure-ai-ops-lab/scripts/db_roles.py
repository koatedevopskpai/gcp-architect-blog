"""Run as DB administrator from the migration Job; never print credentials."""

import os
from urllib.parse import unquote, urlparse

import psycopg2
from psycopg2 import sql


def main():
    with psycopg2.connect(os.environ["ADMIN_DATABASE_URL"]) as conn:
        with conn.cursor() as cursor:
            for env_name in (
                "API_DATABASE_URL",
                "WORKER_DATABASE_URL",
                "MIGRATION_DATABASE_URL",
            ):
                parsed = urlparse(os.environ[env_name])
                if parsed.username is None or parsed.password is None:
                    raise ValueError("database URL must contain credentials")
                name, password = unquote(parsed.username), unquote(parsed.password)
                cursor.execute("SELECT 1 FROM pg_roles WHERE rolname=%s", (name,))
                if not cursor.fetchone():
                    cursor.execute(
                        sql.SQL("CREATE ROLE {} LOGIN PASSWORD %s").format(
                            sql.Identifier(name)
                        ),
                        (password,),
                    )
                else:
                    cursor.execute(
                        sql.SQL("ALTER ROLE {} PASSWORD %s").format(
                            sql.Identifier(name)
                        ),
                        (password,),
                    )
            cursor.execute(
                sql.SQL("GRANT migrator TO {}").format(
                    sql.Identifier(conn.get_dsn_parameters()["user"])
                )
            )
            cursor.execute("ALTER SCHEMA public OWNER TO migrator")
            cursor.execute("GRANT CONNECT ON DATABASE app TO api,worker,migrator")
            cursor.execute("GRANT USAGE ON SCHEMA public TO api,worker")
            cursor.execute("""ALTER DEFAULT PRIVILEGES FOR ROLE migrator
                              IN SCHEMA public GRANT SELECT,INSERT,UPDATE,DELETE
                              ON TABLES TO api,worker""")
    print("database roles configured")


if __name__ == "__main__":
    main()
