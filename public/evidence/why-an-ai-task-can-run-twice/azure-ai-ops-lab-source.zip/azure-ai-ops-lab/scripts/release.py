"""Output-driven Azure release. Run from repo root after CI and OIDC login."""

import argparse
import json
import os
import re
import subprocess
import tempfile
import time
from pathlib import Path

from scripts.smoke import run as smoke


def az(*args, allow_missing=False):
    result = subprocess.run(
        ["az", *args, "--only-show-errors", "-o", "json"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode:
        if allow_missing:
            return None
        # Azure errors can echo deployment arguments. Keep raw stderr private.
        raise RuntimeError(f"Azure command failed: {' '.join(args[:3])}")
    return json.loads(result.stdout) if result.stdout.strip() else None


def deploy(group, template, name, params, what_if=False):
    fd, filename = tempfile.mkstemp(suffix=".json")
    try:
        os.chmod(filename, 0o600)
        with os.fdopen(fd, "w") as file:
            json.dump(
                {"parameters": {k: {"value": v} for k, v in params.items()}}, file
            )
        if what_if:
            az(
                "deployment",
                "group",
                "what-if",
                "-g",
                group,
                "-f",
                template,
                "--parameters",
                "@" + filename,
                "--result-format",
                "ResourceIdOnly",
            )
        value = az(
            "deployment",
            "group",
            "create",
            "-g",
            group,
            "-n",
            name,
            "-f",
            template,
            "--parameters",
            "@" + filename,
        )
        return {k: v["value"] for k, v in value["properties"]["outputs"].items()}
    finally:
        Path(filename).unlink(missing_ok=True)


def wait_execution(group, job, execution, image, limit=660):
    end = time.monotonic() + limit
    while time.monotonic() < end:
        run = az(
            "containerapp",
            "job",
            "execution",
            "show",
            "-g",
            group,
            "--name",
            job,
            "--job-execution-name",
            execution,
        )
        if run["properties"]["template"]["containers"][0]["image"] != image:
            raise RuntimeError("migration execution used an unexpected image")
        status = run["properties"]["status"].lower()
        if status == "succeeded":
            return
        if status in {"failed", "stopped", "degraded"}:
            raise RuntimeError("migration execution failed: " + execution)
        time.sleep(5)
    raise TimeoutError("migration execution deadline: " + execution)


def active_state(group, name):
    app = az("containerapp", "show", "-g", group, "-n", name, allow_missing=True)
    if not app:
        return None
    props = app["properties"]
    return {
        "revision": props["latestReadyRevisionName"],
        "image": props["template"]["containers"][0]["image"],
        "traffic": props["configuration"].get("ingress", {}).get("traffic", []),
    }


def stable_revision(state):
    if not state:
        return ""
    for item in state["traffic"]:
        if item.get("weight") == 100:
            return item.get("revisionName") or state["revision"]
    raise RuntimeError("release requires one captured 100% stable API revision")


def main():
    import asyncio

    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--configure-db-roles", action="store_true")
    args = parser.parse_args()
    cfg = json.loads(Path(args.config).read_text())
    if not re.fullmatch(r"[0-9a-f]{40}", args.commit):
        raise ValueError("use a full lowercase Git commit SHA")
    if "replace-" in json.dumps(cfg) or not cfg["ownerEmail"]:
        raise ValueError("complete infra configuration first")
    group, prefix = cfg["resourceGroup"], cfg["prefix"]
    if not re.fullmatch(r"[a-z][a-z0-9-]{1,10}[a-z0-9]", prefix) or "--" in prefix:
        raise ValueError("prefix must be 3-12 lowercase letters/digits/dashes")
    if cfg["aiMode"] == "azure" and not all(
        cfg[k]
        for k in [
            "aiAccountName",
            "aiResourceGroup",
            "aiEndpoint",
            "aiDeployment",
            "aiApiVersion",
        ]
    ):
        raise ValueError("Azure AI mode requires all existing model settings")
    az(
        "group",
        "create",
        "-n",
        group,
        "-l",
        cfg["location"],
        "--tags",
        "project=azure-ai-ops-lab",
    )
    params = {
        k: cfg[k]
        for k in [
            "location",
            "prefix",
            "ownerEmail",
            "budgetAmount",
            "budgetStart",
            "aiAccountName",
            "aiResourceGroup",
        ]
    }
    for key, env in [
        ("adminPassword", "DB_ADMIN_PASSWORD"),
        ("apiPassword", "API_DB_PASSWORD"),
        ("workerPassword", "WORKER_DB_PASSWORD"),
        ("migrationPassword", "MIGRATION_DB_PASSWORD"),
    ]:
        params[key] = os.environ[env]
        if len(params[key]) < 20:
            raise ValueError("database passwords must have at least 20 characters")
    foundation = deploy(
        group, "infra/bicep/bootstrap.bicep", "foundation", params, True
    )["foundation"]
    subprocess.run(
        [
            "az",
            "acr",
            "build",
            "--registry",
            foundation["acrName"],
            "--image",
            "aiops:" + args.commit,
            ".",
            "--only-show-errors",
        ],
        check=True,
    )
    repo = az(
        "acr",
        "repository",
        "show",
        "--name",
        foundation["acrName"],
        "--image",
        "aiops:" + args.commit,
    )
    image = foundation["registry"] + "/aiops@" + repo["digest"]
    old_api = active_state(group, prefix + "-api")
    old_worker = active_state(group, prefix + "-worker")
    stable = stable_revision(old_api)
    release_id = args.commit[:8] + "-" + str(int(time.time()))
    manifest = {
        "commit": args.commit,
        "image": image,
        "old_api": old_api,
        "old_worker": old_worker,
        "release_id": release_id,
        "azure_cli": az("version"),
    }
    artifact = Path("artifacts")
    artifact.mkdir(exist_ok=True)
    manifest_path = artifact / f"release-{release_id}.json"

    def workload(role, selected_image=image, suffix=release_id):
        values = {
            "foundation": foundation,
            "image": selected_image,
            "role": role,
            "revisionSuffix": suffix,
            "authTenantId": cfg["authTenantId"],
            "authAudience": cfg["authAudience"],
            "stableRevision": stable if role == "api" else "",
            **{
                k: cfg[k]
                for k in ["aiMode", "aiEndpoint", "aiDeployment", "aiApiVersion"]
            },
        }
        return deploy(group, "infra/bicep/workload.bicep", "release-" + role, values)[
            "result"
        ]

    try:
        if old_api is None or args.configure_db_roles:
            bootstrap_job = deploy(
                group,
                "infra/bicep/migration.bicep",
                "role-setup",
                {
                    "foundation": foundation,
                    "image": image,
                    "phase": "bootstrap",
                },
            )["jobName"]
            role_run = az(
                "containerapp", "job", "start", "-g", group, "-n", bootstrap_job
            )
            manifest["role_setup_execution"] = role_run["name"]
            wait_execution(group, bootstrap_job, role_run["name"], image)
        job = deploy(
            group,
            "infra/bicep/migration.bicep",
            "migration",
            {
                "foundation": foundation,
                "image": image,
            },
        )["jobName"]
        execution = az("containerapp", "job", "start", "-g", group, "-n", job)
        manifest["migration_execution"] = execution["name"]
        wait_execution(group, job, execution["name"], image)
        api = workload("api")
        az(
            "containerapp",
            "revision",
            "activate",
            "-g",
            group,
            "-n",
            api["name"],
            "--revision",
            api["revision"],
        )
        az(
            "containerapp",
            "revision",
            "label",
            "add",
            "-g",
            group,
            "-n",
            api["name"],
            "--revision",
            api["revision"],
            "--label",
            "candidate",
        )
        candidate = (
            "https://" + api["name"] + "---candidate." + api["fqdn"].split(".", 1)[1]
        )
        token = az("account", "get-access-token", "--scope", cfg["tokenScope"])
        os.environ["SMOKE_TOKEN"] = token["accessToken"]
        # A failed candidate smoke is not allowed to promote API traffic.
        worker = workload("worker")
        last_error = None
        for _ in range(6):
            try:
                asyncio.run(smoke(candidate))
                last_error = None
                break
            except Exception as exc:
                last_error = exc
                time.sleep(10)
        if last_error:
            raise RuntimeError("candidate smoke failed") from last_error
        az(
            "containerapp",
            "ingress",
            "traffic",
            "set",
            "-g",
            group,
            "-n",
            api["name"],
            "--revision-weight",
            api["revision"] + "=100",
        )
        manifest.update({"api": api, "worker": worker, "status": "succeeded"})
    except Exception:
        manifest["status"] = "failed"
        if old_api:
            az(
                "containerapp",
                "ingress",
                "traffic",
                "set",
                "-g",
                group,
                "-n",
                prefix + "-api",
                "--revision-weight",
                stable + "=100",
            )
        if old_worker:
            workload("worker", old_worker["image"], "rb-" + release_id)
        raise
    finally:
        manifest_path.write_text(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
