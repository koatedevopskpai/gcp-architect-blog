-- Docker initialization only. These passwords are emulator credentials.
CREATE USER migrator PASSWORD 'local-migrate';
CREATE USER api PASSWORD 'local-api';
CREATE USER worker PASSWORD 'local-worker';
ALTER DATABASE app OWNER TO migrator;
ALTER SCHEMA public OWNER TO migrator;
GRANT USAGE ON SCHEMA public TO api,worker;
ALTER DEFAULT PRIVILEGES FOR ROLE migrator IN SCHEMA public
    GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO api,worker;
