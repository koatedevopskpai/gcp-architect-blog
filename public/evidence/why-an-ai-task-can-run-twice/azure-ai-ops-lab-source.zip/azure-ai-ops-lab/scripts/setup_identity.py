"""Operator bootstrap: creates API auth and GitHub OIDC principals.

Requires Graph app-management permission and RBAC assignment permission.
Run once explicitly; this script is not invoked by tests or the deploy workflow.
"""

import argparse
import json
from uuid import uuid4

from scripts.release import az


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", required=True, help="owner/repo")
    parser.add_argument("--resource-group", required=True)
    parser.add_argument("--location", default="uksouth")
    args = parser.parse_args()
    account = az("account", "show")
    group = az(
        "group",
        "create",
        "-n",
        args.resource_group,
        "-l",
        args.location,
        "--tags",
        "project=azure-ai-ops-lab",
    )
    api = az("ad", "app", "create", "--display-name", "aiops-api")
    role_id = str(uuid4())
    az(
        "rest",
        "--method",
        "PATCH",
        "--uri",
        "https://graph.microsoft.com/v1.0/applications/" + api["id"],
        "--body",
        json.dumps(
            {
                "identifierUris": ["api://" + api["appId"]],
                "api": {"requestedAccessTokenVersion": 2},
                "appRoles": [
                    {
                        "id": role_id,
                        "allowedMemberTypes": ["User", "Application"],
                        "displayName": "Lab user",
                        "description": "Use the lab API",
                        "isEnabled": True,
                        "value": "Lab.User",
                    }
                ],
            }
        ),
    )
    api_sp = az("ad", "sp", "create", "--id", api["appId"])
    deploy_app = az("ad", "app", "create", "--display-name", "aiops-github")
    deploy_sp = az("ad", "sp", "create", "--id", deploy_app["appId"])
    az(
        "rest",
        "--method",
        "POST",
        "--uri",
        f"https://graph.microsoft.com/v1.0/applications/{deploy_app['id']}/federatedIdentityCredentials",
        "--body",
        json.dumps(
            {
                "name": "github-lab",
                "issuer": "https://token.actions.githubusercontent.com",
                "subject": f"repo:{args.repository}:environment:lab",
                "audiences": ["api://AzureADTokenExchange"],
            }
        ),
    )
    for role in ("Contributor", "Role Based Access Control Administrator"):
        az(
            "role",
            "assignment",
            "create",
            "--assignee-object-id",
            deploy_sp["id"],
            "--assignee-principal-type",
            "ServicePrincipal",
            "--role",
            role,
            "--scope",
            group["id"],
        )
    az(
        "rest",
        "--method",
        "POST",
        "--uri",
        f"https://graph.microsoft.com/v1.0/servicePrincipals/{deploy_sp['id']}/appRoleAssignments",
        "--body",
        json.dumps(
            {
                "principalId": deploy_sp["id"],
                "resourceId": api_sp["id"],
                "appRoleId": role_id,
            }
        ),
    )
    print(
        json.dumps(
            {
                "AZURE_CLIENT_ID": deploy_app["appId"],
                "AZURE_TENANT_ID": account["tenantId"],
                "AZURE_SUBSCRIPTION_ID": account["id"],
                "authTenantId": account["tenantId"],
                "authAudience": api["appId"],
                "tokenScope": "api://" + api["appId"] + "/.default",
                "apiServicePrincipalId": api_sp["id"],
                "labUserRoleId": role_id,
            },
            indent=2,
        )
    )
    print("Assign human testers to Lab.User in the API enterprise application.")


if __name__ == "__main__":
    main()
