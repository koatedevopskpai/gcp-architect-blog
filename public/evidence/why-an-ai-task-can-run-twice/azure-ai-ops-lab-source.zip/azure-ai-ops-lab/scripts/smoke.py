"""Smoke a running API. Azure uses TOKEN; local uses explicit tenant."""

import argparse
import asyncio
import os
from uuid import uuid4

import httpx


async def run(base):
    token = os.environ.get("SMOKE_TOKEN")
    headers = (
        {"Authorization": f"Bearer {token}"}
        if token
        else {"X-Test-Tenant": "smoke-tenant"}
    )
    async with httpx.AsyncClient(base_url=base, headers=headers, timeout=10) as client:
        (await client.get("/health/ready")).raise_for_status()
        key = str(uuid4())
        payload = {"payload": {"text": "Synthetic invoice 42 was reconciled."}}
        response = await client.post(
            "/tasks",
            json=payload,
            headers={"Idempotency-Key": key},
        )
        response.raise_for_status()
        task_id = response.json()["id"]
        duplicate = await client.post(
            "/tasks",
            json=payload,
            headers={"Idempotency-Key": key},
        )
        assert duplicate.json()["id"] == task_id
        for _ in range(120):
            response = await client.get(f"/tasks/{task_id}")
            response.raise_for_status()
            task = response.json()
            if task["status"] == "completed":
                print("smoke passed", task_id)
                return
            if task["status"] in {"failed", "cancelled", "timed_out"}:
                raise RuntimeError(f"task ended as {task['status']}")
            await asyncio.sleep(1)
        raise TimeoutError("task completion deadline")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default="http://127.0.0.1:8000")
    asyncio.run(run(parser.parse_args().url))
