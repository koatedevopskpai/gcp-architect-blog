#!/usr/bin/env bash
set -euo pipefail
subscription="${1:?subscription id required}"
group="${2:?resource group required}"
actual="$(az account show --query id -o tsv)"
test "$actual" = "$subscription" || { echo 'Subscription mismatch'; exit 1; }
project="$(az group show -n "$group" --query tags.project -o tsv)"
test "$project" = 'azure-ai-ops-lab' || { echo 'Lab tag missing'; exit 1; }
az resource list -g "$group" --query '[].{name:name,type:type}' -o table
az group delete -n "$group" --yes
test "$(az group exists -n "$group" -o tsv)" = 'false'
echo 'Resource-group deletion verified. Check retained vaults, external roles and billing separately.'
