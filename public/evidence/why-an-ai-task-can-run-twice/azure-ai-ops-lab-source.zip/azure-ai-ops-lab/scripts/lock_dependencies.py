"""Recreate exact installed dependency locks after deliberate upgrades.

Run in a clean Python 3.14 environment with all runtime/dev roots installed.
Locks omit conditional dependencies not needed on the resolving platform.
Use CI's Linux run as the final cross-platform installation check.
"""

from importlib import metadata
from pathlib import Path

from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

RUNTIME = [
    "fastapi",
    "uvicorn",
    "sqlalchemy",
    "asyncpg",
    "alembic",
    "pydantic-settings",
    "PyJWT",
    "cryptography",
    "azure-identity",
    "azure-storage-queue",
    "azure-monitor-opentelemetry",
    "openai",
    "httpx",
    "aiohttp",
    "psycopg2-binary",
]
DEV = ["pytest", "pytest-asyncio", "ruff", "mypy", "PyYAML", "types-PyYAML"]


def resolve(roots):
    selected = {}
    pending = list(roots)
    while pending:
        name = canonicalize_name(pending.pop())
        if name in selected:
            continue
        dist = metadata.distribution(name)
        selected[name] = f"{dist.metadata['Name']}=={dist.version}"
        for raw in dist.requires or []:
            req = Requirement(raw)
            if req.marker is None or req.marker.evaluate({"extra": ""}):
                pending.append(req.name)
    return selected


if __name__ == "__main__":
    runtime = resolve(RUNTIME)
    dev = resolve(DEV)
    header = "# Resolved with Python 3.14; 23 October 2026.\n"
    Path("requirements.txt").write_text(
        header + "\n".join(runtime[k] for k in sorted(runtime)) + "\n",
    )
    Path("requirements-dev.txt").write_text(
        header
        + "-r requirements.txt\n"
        + "\n".join(dev[k] for k in sorted(dev.keys() - runtime.keys()))
        + "\n",
    )
